package ejercicio;
import java.util.*;
import java.lang.Math;

public class Coordenada {
	private double x;
	private double y;
	
	public Coordenada() {
		this.x = 0;
		this.y = 0;
	}
	//Constructor
	public Coordenada(double x, double y ){
	 this.x = x;
	 this.y = y;
	}
	//Constructor
	public Coordenada(Coordenada c ){
	 this.x = c.getX();
	 this.y = c.getY();
	}
	//métodos setter
	void setX(double x) {
		this.x = x;
	 // fill in the code here
	}
	void setY(double y){
		this.y = y;
	 // fill in the code here
	}
	//métodos getter
	double getX(){
		return this.x;
	 // fill in the code here
	}
	double getY(){
		return this.y;
	 // fill in the code here
	}
	//método de instancia que calcula la distancia euclideana
	double distancia(Coordenada c){
		return Math.sqrt(Math.pow(c.getX() - this.x, 2) + Math.pow(c.getY() - this.y, 2));
	 // fill in the code here
	}
	//método de clase que calcula la distancia euclideana
	static double distancia(Coordenada c1, Coordenada c2){
		return Math.sqrt(Math.pow(c2.getX() - c1.getX(), 2) + Math.pow(c2.getY() - c1.getY(), 2));
	}
	//método que devuelve los valores de una coordenada en determinado formato
	@Override
	public String toString(){
		return "Point{X: " + x + ", Y: " + y + "}";
	}

}
