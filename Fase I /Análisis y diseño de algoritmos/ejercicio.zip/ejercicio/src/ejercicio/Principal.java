package ejercicio;

public class Principal {

	public static void main(String[] args) {
		Coordenada a1 = new Coordenada(7.6, 2.2);
		Coordenada a2 = new Coordenada(1.5, 0.3);
		Rectangulo A = new Rectangulo(a1, a2);
		
		Coordenada b1 = new Coordenada(9.4, -2.5);
		Coordenada b2 = new Coordenada(4.0, 4.2);
		Rectangulo B = new Rectangulo(b1, b2);
		
		// TODO Auto-generated method stub

	}

}
