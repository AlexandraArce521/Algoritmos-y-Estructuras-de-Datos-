package ejercicio;

public class Verificador {
	//  Los rectángulos A y B se sobreponen
	public static boolean esSobrePos(Rectangulo r1, Rectangulo r2){
		double r1x1 = r1.getEsquina1().getX();
		double r1x2 = r1.getEsquina2().getX();
		double r1y1 = r1.getEsquina1().getY();
		double r1y2 = r1.getEsquina2().getY();
		
		double r2x1 = r2.getEsquina1().getX();
		double r2x2 = r2.getEsquina2().getX();
		double r2y1 = r2.getEsquina1().getY();
		double r2y2 = r2.getEsquina2().getY();
		if (r2x1 > r1x1 || r2x2 > r1x2 || r2y1 <r1y1 || r2y2 > r1y2) {
			return true;
		}
		return false;
	}

	// Los rectángulos A y B están juntos
	public static boolean esJunto(Rectangulo r1, Rectangulo r2){
		double r1x1 = r1.getEsquina1().getX();
		double r1x2 = r1.getEsquina2().getX();
		double r1y1 = r1.getEsquina1().getY();
		double r1y2 = r1.getEsquina2().getY();
		
		double r2x1 = r2.getEsquina1().getX();
		double r2x2 = r2.getEsquina2().getX();
		double r2y1 = r2.getEsquina1().getY();
		double r2y2 = r2.getEsquina2().getY();
		return true;
	}
	
	// Los rectángulos A and B son disjuntos
	public static boolean esDinjunto(Rectangulo r1, Rectangulo r2){
		 return !(esSobrePos(r1, r2) || esJunto(r1, r2));
	}
}
